public class Principal {
    public static void main(String[] args){
        //System.out.println("Olá meu chapa");

        Carro car = new Carro("Audi", "A5", 2024);

        car.venda();
    }
    

}