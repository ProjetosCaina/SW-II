import javax.swing.JOptionPane;

public class Carro extends Auto{

    public Carro(String marca, String ncarro, int ano) {
        super(marca, ncarro, ano);

    }

    public void venda(){

        this.setMarca("Ferrari");
        this.setNcarro("Enzo");
        this.setAno(2002);
        
        JOptionPane.showMessageDialog(null,

        "a marca do carro é: " + this.getMarca() + 
        "\n O nome do carro é: " + this.getNcarro() +
        "\n O ano é: "+ this.getAno()
        
        );
    }
    
}
